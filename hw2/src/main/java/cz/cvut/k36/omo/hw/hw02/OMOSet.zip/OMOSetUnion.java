/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.k36.omo.hw.hw02;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author fuji
 */
public class OMOSetUnion implements OMOSetView  {
    private OMOSetView A;
    private OMOSetView B;
    Set<Integer> list1;
    
    //constructor
    OMOSetUnion(OMOSetView setA, OMOSetView setB) {
        list1 = new HashSet<>();
        A = setA;
        B = setB;
        for (int i = 0 ; i < A.toArray().length; i++){
            list1.add(A.toArray()[i]);
        }
        for (int i = 0 ; i < B.toArray().length; i++){
            list1.add(B.toArray()[i]);
        }
   }
    
    @Override
    public boolean contains(int element) {
        return (A.contains(element) || B.contains(element));
    }

    @Override
    public int[] toArray() {
        int[] integers = new int[list1.size()];
        int j = 0;
        for (Integer i : list1){
            integers[j]=i;
            j++;
        }
        return integers;   
    }

    @Override
    public OMOSetView copy() {
        list1 = new HashSet<>();
        for (int i = 0 ; i < A.toArray().length; i++){
            list1.add(A.toArray()[i]);
        }
        for (int i = 0 ; i < B.toArray().length; i++){
            list1.add(B.toArray()[i]);
        }
        return new OMOSet(list1);
    }
    
}
